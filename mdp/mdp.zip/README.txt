What I learned from this assignment
-How to find optimal routes given a number of steps, or on infinite horizon.

Favorite thing about CS463 this semester
-The writing assignments about current AI topics, especially the one on Computer Generated Humor.